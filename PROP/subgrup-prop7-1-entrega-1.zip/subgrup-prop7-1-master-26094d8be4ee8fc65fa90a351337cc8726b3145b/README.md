# Subgrup PROP 7.1

Casacuberta Gil, Pol

Moreno Martínez, Edgar

Prat Colomer, Maria

Vega Gallego, Pablo

pol.casacuberta@estudiantat.upc.edu

edgar.moreno.martinez@estudiantat.upc.edu

maria.prat@estudiantat.upc.edu

pablo.vega.gallego@estudiantat.upc.edu

maria.prat.colomer@gmail.com

mariaprat21@gmail.com

48213850+EdgarMM19@users.noreply.github.com