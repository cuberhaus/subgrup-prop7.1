# Instruccions de compilació i execució

Si executes make sense cap part, compiles el main.

Si executes make run, s'executa el main.

Si executes make Driver+nomDeLaClasseQueVolsTestejar, compiles i executes el driver dessitjat.

Si executes make NomClasseTest s'executa el UT corresponent.

Si executes make jocX s'executa el joc de prova X.
