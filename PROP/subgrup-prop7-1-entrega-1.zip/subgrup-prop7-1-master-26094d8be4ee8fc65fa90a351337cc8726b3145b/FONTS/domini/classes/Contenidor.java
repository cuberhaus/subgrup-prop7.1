package domini.classes;

/**
 * Classe que representa un contenidor de dades d'un fitxer
 * @author pablo.vega
 */
public class Contenidor {
    public Contenidor() {}
}
